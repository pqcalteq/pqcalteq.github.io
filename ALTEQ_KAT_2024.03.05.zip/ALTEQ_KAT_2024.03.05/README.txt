This folder contains the Known Answer tests, and a procedure to compare them.

--------------------------------------------------------------------------------------

the witness files are very small, as they contain mostly hashes.
the validity of this KAT method relies on the security of SHA3.

--------------------------------------------------------------------------------------


To generate KAT File for reference code:
- import code: "make import_ref"
- build files: "make test_ref_hash"
- check files: "make check_ref_h"

To generate KAT File for optimized code:
- import code: "make import_opt"
- build files: "make test_opt_hash"
- check files: "make check_opt_h"

--------------------------------------------------------------------------------------

All-in-one commands, for ref and opt:
- "make KAT_ref"
- "make KAT_opt"

--------------------------------------------------------------------------------------

To clean:
- code: "make clean"
- previous kat files: "make distclean"