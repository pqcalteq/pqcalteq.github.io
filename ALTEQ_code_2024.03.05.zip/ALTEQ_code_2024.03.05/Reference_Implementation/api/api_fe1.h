#define LAMBDA  128
#define N  13
#define LOG_Q  32
#define PRIME  4294967291lu
#define C  7
#define K  22
#define ROUND 84