#define LAMBDA  256
#define N  25
#define LOG_Q  32
#define PRIME  4294967291lu
#define C  227
#define K  25
#define ROUND 67