#define LAMBDA  192
#define N  20
#define LOG_Q  32
#define PRIME  4294967291lu
#define C  229
#define K  20
#define ROUND 39