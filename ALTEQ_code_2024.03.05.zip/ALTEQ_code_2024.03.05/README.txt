

ALTEQ
======

This folder contains the subfolders

KAT
Refernece_Implementation
Optimized_Implementation
Supporting_Documentation



----------------------
KAT
This folder contains the Known Answer Test values of our implementation.
For additional details, please refer to the KAT/README.txt.




---------------------------------
Reference_Implementation
This folder contains the reference implementation of ALTEQ.
The subfolder /api contains 6 sets of recommended parameters as follows:

api_fe1.h
This aims for NIST level I security with recommended parameter "N=13,Log_Q=32,ROUND=84,K=22,C=7"

api_lp1.h
This aims for NIST level I security with recommended parameter "N=13,Log_Q=32,ROUND=16,K=14,C=458"

api_fe3.h
This aims for NIST level III security with recommended parameter "N=20,Log_Q=32,ROUND=201,K=28,C=7"

api_lp3.h
This aims for NIST level III security with recommended parameter "N=20,Log_Q=32,ROUND=39,K=20,C=229"

api_fe5.h
This aims for NIST level V security with recommended parameter "N=25,Log_Q=32,ROUND=119,K=48,C=8"

api_lp5.h
This aims for NIST level V security with recommended parameter "N=25,Log_Q=32,ROUND=67,K=25,C=227"

api_tail.h
Contains the different options for other parameters:
  - enable the salt to patch for Beullens' attack
  - Customize the seed size for the secret key matrices, the signature matrices, the public key, etc...
  - replace aes-256 by Keccak when necessary (seed size > 256)



The Makefile provide a command to build the "api.h" file that is used for the whole program:
"make api_h API_TYPE=XX" build "api_h" for XX=fe1 or XX=lp5 for example

The Makefile also provide users with commands to measure the performance by:
  - the number of cycles through "make test_speed_all"
  - the CPU time through "test_CPU_time"


Note that the extensions:
 - "fe" stands for "Fully Equlibrated" and correspond to "Balanced" in the supporting documentation
 - "lp" stands for "Large Public Key" and correspond to "ShortSig" in the supporting documentation



---------------------------------
Optimized_Implementation
This folder contains an optimized implementation of ALTEQ, giving the same outputs as the above.
Essentially, almost all the files are identical, but compiled with performances options such as -mavx2.

The main differences concern the folder aes and the folder keccak, that contained avx optimized versions.
Those optimized versions were ``copy-pasted" from the Dilithium submission (that became ML-DSA) and XKCP.




---------------------------------
Supporting_Documentation
This folder contains the cover sheet, signed statement of each submitter and the file ALTEQ_Documentation.pdf.
The file ALTEQ_Documentation contains information concerning our scheme, namely:
  - algorithm specification
  - performance data
  - implementation details
  - security analysis
  - advantage and limitations

