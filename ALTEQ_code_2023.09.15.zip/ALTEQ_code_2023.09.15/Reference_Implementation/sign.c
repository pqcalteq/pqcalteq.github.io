#include <stdlib.h>
#include <string.h>

#include <mm_malloc.h>
#include <stdint.h>

#include "api.h"
#include "compress.h"
#include "expand.h"
#include "matrix.h"
#include "atf.h"
#include "vec_sizes.h"

int crypto_sign_keypair(uint8_t  *pk, uint8_t  *sk)
{
  int i, r;

  uint8_t * seeds = (uint8_t *)_mm_malloc(sizeof(uint8_t ) * SEED_SIZE* (C+1), 64);
  uint32_t* atfC  = (uint32_t*)_mm_malloc(sizeof(uint32_t) * LEN * NB32_VEC_C, 64);
  uint32_t* cols  = (uint32_t*)_mm_malloc(sizeof(uint32_t) * N*N * NB32_VEC_C, 64);

  memset(pk, 0x00, CRYPTO_PUBLICKEYBYTES);
  memset(sk, 0x00, CRYPTO_SECRETKEYBYTES);

  randomSeed(sk);

  /* Expanding Secret Key */
  expandSeeds(seeds, sk, C+1);

  /* Generating N Columns Matrices such that acting on ATF_i with columns matrices i return atf_C */
  for (r = 0; r < C; r++)
      expandColumns(atfC + r * NB32_VEC_NN, seeds + r * SEED_SIZE);
    for(i=0;i<N*N;i++)
      for(r=0; r<NB32_VEC_C; r++)
        cols[i*NB32_VEC_C + r]=atfC[r*NB32_VEC_NN+i];

  /* Expanding ATF_C */
  expandATF_vec_copy(atfC, seeds+C*SEED_SIZE, NB32_VEC_C, NB32_VEC_C);
  invertingOnATF((uint32_t*)(pk), atfC, cols);

  /* Keeping Seed for ATF_C in both key (appended at the tail) */
  memcpy(pk+C*ALT_SIZE, seeds+C*SEED_SIZE, SEED_SIZE);

  /* free */
  _mm_free(seeds);
  _mm_free(atfC);
  _mm_free(cols);

  return 0;
}


int crypto_sign(uint8_t  *sm, uint64_t *smlen, const uint8_t  *m, uint64_t mlen, const uint8_t  *sk)
{

  uint8_t * hash = (uint8_t *)_mm_malloc(sizeof(uint8_t) * (ALT_SIZE * NB32_VEC_ROUND + 2 * SEED_SIZE), 64);
  uint8_t * seeds_sk = (uint8_t *)_mm_malloc(sizeof(uint8_t) * SEED_SIZE * (C + 1), 64);
  uint32_t* atfC = (uint32_t *)_mm_malloc(sizeof(uint32_t) * LEN * NB32_VEC_ROUND, 64);
  uint8_t * seeds = (uint8_t *)_mm_malloc(sizeof(uint8_t) * SEED_SIZE * ROUND, 64);
  uint32_t* cols_rnd = (uint32_t *)_mm_malloc(sizeof(uint32_t) * NB32_VEC_NN * NB32_VEC_ROUND, 64);
  uint32_t* cols = (uint32_t *)_mm_malloc(sizeof(uint32_t) * N * N * NB32_VEC_K, 64);

  uint64_t cols_exp[C];
  uint64_t chg_c[ROUND - K];
  uint64_t chg_nc[K];
  uint64_t chg_val[K];

  uint32_t* tmp_ptr;
  int success;


  int i, r, j;

  if (!mlen){
    /* free and exit */
    _mm_free(hash);
    _mm_free(seeds_sk);
    _mm_free(atfC);
    _mm_free(seeds);
    _mm_free(cols_rnd);
    _mm_free(cols);
    return -1;}

  /* this hold the most space by far, and is often unusued: it is good as a temporary buffer */
  tmp_ptr = (uint32_t *)(hash + 2 * SEED_SIZE);


  memset(hash, 0x00, ALT_SIZE * ROUND + 2 * SEED_SIZE);
  memset(sm, 0x00, CRYPTO_BYTES);

  /* Expanding Secret Key  */
  expandSeeds(seeds_sk, sk, C + 1);

  expandATF_vec_copy(atfC, &(seeds_sk[C * SEED_SIZE]), NB32_VEC_ROUND, NB32_VEC_ROUND);

  hashArray(hash, m, mlen);

  do
  {
    success = 1;
    memset(cols_exp, 0x00, C * 8);

    /* Creating ROUND random N Columns matrices */
    randomSeed(seeds);
    expandSeeds(seeds, seeds, ROUND);

    /* expand then put into vectorized form */
    /* we need to keep a non-vectorized version of cols_rnd because of random challenge picking */
    /* it is either this, or re-expanding the columns later/reorganizing (which is also cheap)*/
    for (r = 0; r < ROUND; r++)
      expandColumns(cols_rnd + r * NB32_VEC_NN, seeds + r * SEED_SIZE);
    for (i = 0; i < N * N; i++)
      for (r = 0; r < NB32_VEC_ROUND; r++)
        tmp_ptr[i * NB32_VEC_ROUND + r] = cols_rnd[r * NB32_VEC_NN + i];

    /* Acting independently on ATFC ROUND time */
    actingOnATFS(tmp_ptr, atfC, tmp_ptr); /* careful tmp_ptr also contains hash */

    /* Creating Challenge from hash */
    hashArray(sm, hash, ALT_SIZE * ROUND + 2 * SEED_SIZE);

    expandChallenge(chg_c, chg_nc, chg_val, sm);

    /* overwrite cols_rnd to align properly necessary matrices for the rest of the program, and vectorize it */
    for (r = 0; r < K; r++)
      memcpy(tmp_ptr + NB32_VEC_NN * r, cols_rnd + NB32_VEC_NN * chg_nc[r], sizeof(uint32_t) * NB32_VEC_NN);
    /* vectorize the result */
    for (i = 0; i < N * N; i++)
      for (r = 0; r < K; r++)
        cols_rnd[i * NB32_VEC_K + r] = tmp_ptr[r * NB32_VEC_NN + i];

    /* Keeping Seeds for column matrices corresponding to challenge =C */
    for (r = 0; r < ROUND - K; r++)
      for (j = 0; j < SEED_SIZE; j++)
        memcpy((sm + 2 * SEED_SIZE) + r * SEED_SIZE, seeds + chg_c[r] * SEED_SIZE, sizeof(uint8_t) * SEED_SIZE);

    /* Expanding KxN Columns matrices from the CxN from Secret Key: assume duplicates for vectorization */
#if C < K /* many collisions */
    for (r = 0; r < K; r++)
      if (cols_exp[chg_val[r]]++ == 0)
      {
        expandColumns(tmp_ptr + NB32_VEC_NN * r, seeds_sk + chg_val[r] * SEED_SIZE);
        chg_c[chg_val[r]] = r; /* store the position in which it has already been generated */
      }
      else
      {
        memcpy(tmp_ptr + NB32_VEC_NN * r, tmp_ptr + NB32_VEC_NN * chg_c[chg_val[r]], sizeof(uint32_t) * NB32_VEC_NN);
      }
#else  /* C>K very few or no collisions */
    for (r = 0; r < K; r++)
      expandColumns(tmp_ptr + NB32_VEC_NN * r, seeds_sk + chg_val[r] * SEED_SIZE);
#endif /*C<K or K>C */
    /* vectorize the result */
    for (i = 0; i < N * N; i++)
      for (r = 0; r < K; r++)
        cols[i * NB32_VEC_K + r] = tmp_ptr[r * NB32_VEC_NN + i];

    /* Construct K Matrices corresponding to challenge !=C */
    columnsMatrix(tmp_ptr, cols_rnd, cols, NB32_VEC_K);
    success = columnsDecomposition(tmp_ptr, NB32_VEC_K, K);

    /* this output is vectorized! Do not load useless elements when NB32_VEC_K > K */
    for (r = 0; r < N * N; r++)
    {
      memcpy(((uint32_t *)(sm + (2 * SEED_SIZE + (ROUND - K) * SEED_SIZE))) + r * K, tmp_ptr, sizeof(uint32_t) * K);
      tmp_ptr += NB32_VEC_K;
    }
  } while (!success);

  *smlen = CRYPTO_BYTES;
  *smlen += mlen;
  memcpy(sm + CRYPTO_BYTES, m, mlen);

  /* free */
  _mm_free(hash);
  _mm_free(seeds_sk);
  _mm_free(atfC);
  _mm_free(seeds);
  _mm_free(cols_rnd);
  _mm_free(cols);

  return 0;
}


int crypto_sign_open(uint8_t  *m, uint64_t *mlen, const uint8_t  *sm, uint64_t smlen, const uint8_t  *pk)
{
  int correct=0;
  int r, i;

  uint8_t  *hash = (uint8_t  *)_mm_malloc(sizeof(uint8_t) * (ALT_SIZE * ROUND + 2 * SEED_SIZE), 64);
  uint32_t *cols = (uint32_t *)_mm_malloc(sizeof(uint32_t) * N * N * NB32_VEC_ROUND, 64);
  uint32_t *atfs = (uint32_t *)_mm_malloc(sizeof(uint32_t) * LEN * NB32_VEC_ROUND, 64);

  uint8_t  chk[2*SEED_SIZE];
  uint64_t chg_c[ROUND-K];
  uint64_t chg_nc[K];
  uint64_t chg_val[K];

  memset(chk, 0x00, 2 * SEED_SIZE);
  memset(hash, 0x00, ALT_SIZE * ROUND + 2 * SEED_SIZE);

  *mlen = smlen - CRYPTO_BYTES;
  memcpy(m, sm + CRYPTO_BYTES, *mlen);

  /* Expanding ROUND-K  N Columns Matrices correponding to challenge =C  */
  /* use atfs as a temporary buffer */
  for (r = 0; r < ROUND - K; r++)
    expandColumns(atfs + r * NB32_VEC_NN, sm + (2 + r) * SEED_SIZE);
  /* pre-vectorize data before loading the vectorized data after */
  for (i = 0; i < N * N; i++)
    for (r = 0; r < ROUND - K; r++)
      cols[i * NB32_VEC_ROUND + r] = atfs[r * NB32_VEC_NN + i];

  /* Extract matrix for challenge <C*/
  /* load vectorized data, packs of K elements */
  for (i = 0; i < N * N; i++)
    memcpy(cols + (i * NB32_VEC_ROUND) + ROUND - K,
           ((uint32_t *)(sm + ((2 + ROUND - K) * SEED_SIZE))) + i * K,
           K * sizeof(uint32_t));

  /* check values are all within [0, PRIME [: avoid signature forgeries by just adding values */
  for (i = 0; i < N * N ; i++)
    for (r = ROUND - K; r < ROUND; r++)
      correct |= (cols[i * NB32_VEC_ROUND + r] >= PRIME);
  /* check diagonal values are non-zero */
  for (i = 0; i < N; i++)
    for (r = ROUND - K; r < ROUND; r++)
      correct |= (cols[(i * (N + 1)) * NB32_VEC_ROUND + r] == 0);

  /* Expanding Challenge  */
  expandChallenge(chg_c, chg_nc, chg_val, sm);

  /* expanding and copy-pasting of the ATF (ROUND-K copies) need to vectorize properly (use vectorized ATFS) */
  expandATF_vec_copy(atfs, pk + C * ALT_SIZE, NB32_VEC_ROUNDmK, NB32_VEC_ROUND);
  /* Extract and vectorize corresponding ATF for challenge <C*/
  for (i = 0; i < LEN; i++)
    for (r = 0; r < K; r++)
      atfs[i * NB32_VEC_ROUND + r + ROUND - K] = ((uint32_t *)(pk + (ALT_SIZE * chg_val[r])))[i];

  actingOnATFS(atfs, atfs, cols);

  /* Preparing Hashing of ROUND-K ATF */
  for (r = 0; r < ROUND - K; r++)
    memcpy(hash + 2 * SEED_SIZE + chg_c[r] * ALT_SIZE, atfs + r * LEN, sizeof(uint32_t) * LEN);

  /* Preparing Hashing with the K last ATF */
  for (r = ROUND - K; r < ROUND; r++)
    memcpy(hash + 2 * SEED_SIZE + chg_nc[r - ROUND + K] * ALT_SIZE, atfs + r * LEN, sizeof(uint32_t) * LEN);

  hashArray(hash, m, *mlen);
  hashArray(chk, hash, ALT_SIZE * ROUND + 2 * SEED_SIZE);

  /* Verfication */
  for (i = 0; i < 2 * SEED_SIZE; i++)
    correct |= (sm[i] != chk[i]);

  /* free */
  _mm_free(hash);
  _mm_free(cols);
  _mm_free(atfs);

  return correct;
}