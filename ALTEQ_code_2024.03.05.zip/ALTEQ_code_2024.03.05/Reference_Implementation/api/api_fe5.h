#define LAMBDA  256
#define N  25
#define LOG_Q  32
#define PRIME  4294967291lu
#define C  8
#define K  48
#define ROUND 119