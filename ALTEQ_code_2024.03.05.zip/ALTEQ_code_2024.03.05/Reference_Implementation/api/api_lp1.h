#define LAMBDA  128
#define N  13
#define LOG_Q  32
#define PRIME  4294967291lu
#define C  458
#define K  14
#define ROUND 16