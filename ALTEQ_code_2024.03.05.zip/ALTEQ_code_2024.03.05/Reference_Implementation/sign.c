#include <stdlib.h>
#include <string.h>

#include <mm_malloc.h>
#include <stdint.h>

#include "api.h"
#include "compress.h"
#include "expand.h"
#include "matrix.h"
#include "atf.h"
#include "vec_sizes.h"

int crypto_sign_keypair(uint8_t  *pk, uint8_t  *sk)
{
  int i, r;

  uint8_t * seeds = (uint8_t *)_mm_malloc(sizeof(uint8_t ) * ((MAT_SK_SEED_SIZE * C) + PK_SEED_SIZE), 64);
  uint32_t* atfC  = (uint32_t*)_mm_malloc(sizeof(uint32_t) * LEN * NB32_VEC_C, 64);
  uint32_t* cols  = (uint32_t*)_mm_malloc(sizeof(uint32_t) * N*N * NB32_VEC_C, 64);

  memset(pk, 0x00, CRYPTO_PUBLICKEYBYTES);
  memset(sk, 0x00, CRYPTO_SECRETKEYBYTES);

  randomSeed(sk, SK_SEED_SIZE);

  /* Expanding Secret Key */
  /* Because MAT_SK_SEED_SIZE and PK_SEED_SIZE might differ, I prefer to consider one single large expansion */
  expandSeeds(seeds, sk, 1, SK_SEED_SIZE, ((MAT_SK_SEED_SIZE * C) + PK_SEED_SIZE));

  /* Generating N Columns Matrices such that acting on ATF_i with columns matrices i return atf_C */
  for (r = 0; r < C; r++)
      expandColumns(atfC + r * NB32_VEC_NN, seeds + r * MAT_SK_SEED_SIZE, MAT_SK_SEED_SIZE);
    for(i=0;i<N*N;i++)
      for(r=0; r<NB32_VEC_C; r++)
        cols[i*NB32_VEC_C + r]=atfC[r*NB32_VEC_NN+i];

  /* Expanding ATF_C */
  expandATF_vec_copy(atfC, seeds+C*MAT_SK_SEED_SIZE, NB32_VEC_C, NB32_VEC_C, PK_SEED_SIZE);
  invertingOnATF((uint32_t*)(pk), atfC, cols);

  /* Keeping Seed for ATF_C in both key (appended at the tail) */
  memcpy(pk+C*ALT_SIZE, seeds+C*MAT_SK_SEED_SIZE, PK_SEED_SIZE);

  /* free */
  _mm_free(seeds);
  _mm_free(atfC);
  _mm_free(cols);

  return 0;
}


int crypto_sign(uint8_t  *sm, uint64_t *smlen, const uint8_t  *m, uint64_t mlen, const uint8_t  *sk)
{

  uint8_t * hash = (uint8_t *)_mm_malloc(sizeof(uint8_t) * (ALT_SIZE * NB32_VEC_ROUND + MSG_HASH_SIZE), 64);
  uint8_t * seeds_sk = (uint8_t *)_mm_malloc(sizeof(uint8_t ) * ((MAT_SK_SEED_SIZE * C) + PK_SEED_SIZE), 64);
  uint32_t* atfC = (uint32_t *)_mm_malloc(sizeof(uint32_t) * LEN * NB32_VEC_ROUND, 64);
  uint8_t * seeds = (uint8_t *)_mm_malloc(sizeof(uint8_t) * EXPCOL_SIG_SEED_SIZE * ROUND, 64);
  uint32_t* cols_rnd = (uint32_t *)_mm_malloc(sizeof(uint32_t) * NB32_VEC_NN * NB32_VEC_ROUND, 64);
  uint32_t* cols = (uint32_t *)_mm_malloc(sizeof(uint32_t) * N * N * NB32_VEC_K, 64);

#if C < K
  uint64_t cols_exp[C];
#endif
  uint64_t chg_c[ROUND - K];
  uint64_t chg_nc[K];
  uint64_t chg_val[K];

  #if USE_SALT == 1
  uint8_t salt_value[SALT_SIZE];
  #endif

  uint32_t* tmp_ptr;
  uint8_t* char_ptr;
  int success;


  int i, r;

  if (!mlen){
    /* free and exit */
    _mm_free(hash);
    _mm_free(seeds_sk);
    _mm_free(atfC);
    _mm_free(seeds);
    _mm_free(cols_rnd);
    _mm_free(cols);
    return -1;}

  /* this hold the most space by far, and is often unusued: it is good as a temporary buffer */
  tmp_ptr = (uint32_t *)(hash + MSG_HASH_SIZE);

  memset(hash, 0x00, ALT_SIZE * ROUND + MSG_HASH_SIZE);
  memset(sm, 0x00, CRYPTO_BYTES);

  /* Expanding Secret Key  */
  /* Because MAT_SK_SEED_SIZE and PK_SEED_SIZE might differ, I prefer to consider one single large expansion */
  expandSeeds(seeds_sk, sk, 1, SK_SEED_SIZE, ((MAT_SK_SEED_SIZE * C) + PK_SEED_SIZE));

  expandATF_vec_copy(atfC, seeds_sk+C*MAT_SK_SEED_SIZE, NB32_VEC_ROUND, NB32_VEC_ROUND, PK_SEED_SIZE);

  hashArray(hash, MSG_HASH_SIZE, m, mlen);

  do
  {
    success = 1;

    /* Creating ROUND random N Columns matrices */
    #if USE_SALT == 0
    randomSeed(seeds, SIG_SEED_SIZE);
    expandSeeds(seeds, seeds, ROUND, SIG_SEED_SIZE, SIG_SEED_SIZE);
    #else
    char_ptr = (uint8_t*)tmp_ptr;
    randomSeed(char_ptr, SIG_SEED_SIZE);
    expandSeeds(char_ptr, char_ptr, ROUND, SIG_SEED_SIZE, SIG_SEED_SIZE);
    /* create a SALT value, then append to every potential signature seed with position i */
    randomSeed(salt_value, SALT_SIZE);
    char_ptr = seeds;
    for (r = 0; r < ROUND; r++){
      /* position for the SEED (not overwritten yet) */
      memcpy(char_ptr, ((uint8_t*)tmp_ptr) + r*SIG_SEED_SIZE, SIG_SEED_SIZE);
      char_ptr += SIG_SEED_SIZE;
      /* position for the SALT */
      memcpy(char_ptr, salt_value, SALT_SIZE);
      char_ptr += SALT_SIZE;
      /* position for the octet id */
      memset(char_ptr, (char)r, 1);
      char_ptr += 1;
    }
    #endif

    /* expand then put into vectorized form */
    /* we need to keep a non-vectorized version of cols_rnd because of random challenge picking */
    /* it is either this, or re-expanding the columns later/reorganizing (which is also cheap)*/
    for (r = 0; r < ROUND; r++)
      expandColumns(cols_rnd + r * NB32_VEC_NN, seeds + r * EXPCOL_SIG_SEED_SIZE, EXPCOL_SIG_SEED_SIZE);
    for (i = 0; i < N * N; i++)
      for (r = 0; r < NB32_VEC_ROUND; r++)
        tmp_ptr[i * NB32_VEC_ROUND + r] = cols_rnd[r * NB32_VEC_NN + i];

    /* Acting independently on ATFC ROUND time */
    actingOnATFS(tmp_ptr, atfC, tmp_ptr); /* careful tmp_ptr also contains hash */

    /* Creating Challenge from hash */
    hashArray(sm, CHLG_SIZE, hash, ALT_SIZE * ROUND + MSG_HASH_SIZE);

    expandChallenge(chg_c, chg_nc, chg_val, sm, CHLG_SIZE);

    /* overwrite cols_rnd to align properly necessary matrices for the rest of the program, and vectorize it */
    for (r = 0; r < K; r++)
      memcpy(tmp_ptr + NB32_VEC_NN * r, cols_rnd + NB32_VEC_NN * chg_nc[r], sizeof(uint32_t) * NB32_VEC_NN);
    /* vectorize the result */
    for (i = 0; i < N * N; i++)
      for (r = 0; r < K; r++)
        cols_rnd[i * NB32_VEC_K + r] = tmp_ptr[r * NB32_VEC_NN + i];

    /* Expanding KxN Columns matrices from the CxN from Secret Key: assume duplicates for vectorization */
#if C < K /* many collisions */
    memset(cols_exp, -1, C * 8); /* basically an unreachable value that will be changed */
    for (r = 0; r < K; r++)
      if (cols_exp[chg_val[r]] == -1)
      {
        expandColumns(tmp_ptr + NB32_VEC_NN * r, seeds_sk + chg_val[r] * MAT_SK_SEED_SIZE, MAT_SK_SEED_SIZE);
        cols_exp[chg_val[r]] = r; /* store the position in which it has already been generated */
      }
      else /* already expanded somewhere, position stored in cols_exp[chg_val[r]] */
      {
        memcpy(tmp_ptr + NB32_VEC_NN * r, tmp_ptr + NB32_VEC_NN * cols_exp[chg_val[r]], sizeof(uint32_t) * NB32_VEC_NN);
      }
#else  /* C>K very few or no collisions */
    for (r = 0; r < K; r++)
      expandColumns(tmp_ptr + NB32_VEC_NN * r, seeds_sk + chg_val[r] * MAT_SK_SEED_SIZE, MAT_SK_SEED_SIZE);
#endif /*C<K or K>C */
    /* vectorize the result */
    for (i = 0; i < N * N; i++)
      for (r = 0; r < K; r++)
        cols[i * NB32_VEC_K + r] = tmp_ptr[r * NB32_VEC_NN + i];

    /* Construct K Matrices corresponding to challenge !=C */
    columnsMatrix(tmp_ptr, cols_rnd, cols, NB32_VEC_K);
    success = columnsDecomposition(tmp_ptr, NB32_VEC_K, K);
  } while (!success);

  /* Finally write the content of the signature */
  char_ptr = sm + CHLG_SIZE;

  #if USE_SALT == 1
  /* write the salt */
  memcpy(char_ptr, salt_value, SALT_SIZE);
  char_ptr += SALT_SIZE;
  #endif

  /* Write the ROUND - K seeds corresponding to challenge =C */
  for (r = 0; r < ROUND - K; r++)
    memcpy(char_ptr + r * SIG_SEED_SIZE, seeds + chg_c[r] * EXPCOL_SIG_SEED_SIZE, sizeof(uint8_t) * SIG_SEED_SIZE);

  /* this output is vectorized! Do not load useless elements when NB32_VEC_K > K */
  char_ptr += ((ROUND - K) * SIG_SEED_SIZE);
  for (r = 0; r < N * N; r++)
    memcpy(((uint32_t *)char_ptr) + r * K, tmp_ptr + r * NB32_VEC_K, sizeof(uint32_t) * K);

  *smlen = CRYPTO_BYTES;
  *smlen += mlen;
  memcpy(sm + CRYPTO_BYTES, m, mlen);

  /* free */
  _mm_free(hash);
  _mm_free(seeds_sk);
  _mm_free(atfC);
  _mm_free(seeds);
  _mm_free(cols_rnd);
  _mm_free(cols);

  return 0;
}


int crypto_sign_open(uint8_t  *m, uint64_t *mlen, const uint8_t  *sm, uint64_t smlen, const uint8_t  *pk)
{
  int correct=0;
  int r, i;

  uint8_t  *hash = (uint8_t  *)_mm_malloc(sizeof(uint8_t) * (ALT_SIZE * ROUND + MSG_HASH_SIZE), 64);
  uint32_t *cols = (uint32_t *)_mm_malloc(sizeof(uint32_t) * N * N * NB32_VEC_ROUND, 64);
  uint32_t *atfs = (uint32_t *)_mm_malloc(sizeof(uint32_t) * LEN * NB32_VEC_ROUND, 64);
  #if USE_SALT == 0
  const uint8_t* seeds_sig = sm + CHLG_SIZE;
  #else
  uint8_t* seeds_sig = (uint8_t*)_mm_malloc(sizeof(uint8_t) * (EXPCOL_SIG_SEED_SIZE * (ROUND-K)), 64);
  #endif

  uint8_t  chk[CHLG_SIZE];
  uint64_t chg_c[ROUND-K];
  uint64_t chg_nc[K];
  uint64_t chg_val[K];

  #if USE_SALT == 1
  uint8_t salt_value[SALT_SIZE];
  #endif

  uint8_t* char_ptr;
  uint8_t* char_ptr_out;


  memset(chk, 0x00, CHLG_SIZE);
  memset(hash, 0x00, ALT_SIZE * ROUND + MSG_HASH_SIZE);

  *mlen = smlen - CRYPTO_BYTES;
  memcpy(m, sm + CRYPTO_BYTES, *mlen);

  /* Expanding Challenge */
  expandChallenge(chg_c, chg_nc, chg_val, sm, CHLG_SIZE);

  #if USE_SALT == 1
  /* recover the salt appended to the end of the signature */
  char_ptr = ((uint8_t*)sm) + CHLG_SIZE;
  memcpy(salt_value, char_ptr, SALT_SIZE);
  char_ptr += SALT_SIZE;
  char_ptr_out = seeds_sig;
  /* set the seeds that have to be expanded for signature column matrices */
  for (r = 0; r < ROUND - K; r++){
    memcpy(char_ptr_out, char_ptr, SIG_SEED_SIZE);
    char_ptr += SIG_SEED_SIZE;
    char_ptr_out += SIG_SEED_SIZE;
    /* position for the SALT */
    memcpy(char_ptr_out, salt_value, SALT_SIZE);
    char_ptr_out += SALT_SIZE;
    /* position for the octet id */
    memset(char_ptr_out, chg_c[r], 1);
    char_ptr_out += 1;
  }
  #endif

  /* Expanding ROUND-K  N Columns Matrices correponding to challenge =C  */
  /* use atfs as a temporary buffer */
  for (r = 0; r < ROUND - K; r++)
    expandColumns(atfs + r * NB32_VEC_NN, seeds_sig + (r * EXPCOL_SIG_SEED_SIZE), EXPCOL_SIG_SEED_SIZE);
  /* pre-vectorize data before loading the vectorized data after */
  for (i = 0; i < N * N; i++)
    for (r = 0; r < ROUND - K; r++)
      cols[i * NB32_VEC_ROUND + r] = atfs[r * NB32_VEC_NN + i];

  /* Extract matrix for challenge <C*/
  /* load vectorized data, packs of K elements */
  char_ptr = (uint8_t*)(sm + CHLG_SIZE + SALT_SIZE + ((ROUND - K) * SIG_SEED_SIZE));
  for (i = 0; i < N * N; i++)
    memcpy(cols + (i * NB32_VEC_ROUND) + ROUND - K, (uint32_t *)(char_ptr) + i * K, K * sizeof(uint32_t));

  /* check values are all within [0, PRIME [: avoid signature forgeries by just adding values */
  for (i = 0; i < N * N ; i++)
    for (r = ROUND - K; r < ROUND; r++)
      correct |= (cols[i * NB32_VEC_ROUND + r] >= PRIME);
  /* check diagonal values are non-zero */
  for (i = 0; i < N; i++)
    for (r = ROUND - K; r < ROUND; r++)
      correct |= (cols[(i * (N + 1)) * NB32_VEC_ROUND + r] == 0);

  /* expanding and copy-pasting of the ATF (ROUND-K copies) need to vectorize properly (use vectorized ATFS) */
  expandATF_vec_copy(atfs, pk + C * ALT_SIZE, NB32_VEC_ROUNDmK, NB32_VEC_ROUND, PK_SEED_SIZE);
  /* Extract and vectorize corresponding ATF for challenge <C*/
  for (i = 0; i < LEN; i++)
    for (r = 0; r < K; r++)
      atfs[i * NB32_VEC_ROUND + r + ROUND - K] = ((uint32_t *)(pk + (ALT_SIZE * chg_val[r])))[i];

  actingOnATFS(atfs, atfs, cols);

  /* Preparing Hashing of ROUND-K ATF */
  char_ptr = hash + MSG_HASH_SIZE;
  for (r = 0; r < ROUND - K; r++)
    memcpy(char_ptr + chg_c[r] * ALT_SIZE, atfs + r * LEN, sizeof(uint32_t) * LEN);

  /* Preparing Hashing with the K last ATF */
  for (r = ROUND - K; r < ROUND; r++)
    memcpy(char_ptr + chg_nc[r - ROUND + K] * ALT_SIZE, atfs + r * LEN, sizeof(uint32_t) * LEN);

  hashArray(hash, MSG_HASH_SIZE, m, *mlen);
  hashArray(chk, CHLG_SIZE, hash, ALT_SIZE * ROUND + MSG_HASH_SIZE);

  /* Verfication */
  for (i = 0; i < CHLG_SIZE; i++)
    correct |= (sm[i] != chk[i]);

  /* free */
  _mm_free(hash);
  _mm_free(cols);
  _mm_free(atfs);
  #if USE_SALT == 1
  _mm_free(seeds_sig);
  #endif

  return correct;
}