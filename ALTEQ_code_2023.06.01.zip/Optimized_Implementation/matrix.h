#ifndef MATRIX_H_
#define MATRIX_H_

#include "api.h"
#include "field.h"

extern void columnsMatrix(uint64_t *mat, const uint64_t *colsA, const uint64_t *colsB);

#endif
